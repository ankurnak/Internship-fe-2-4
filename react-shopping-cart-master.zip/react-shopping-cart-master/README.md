Интернет-магазин книг - [Demo](http://react-redux-shopping-cart.surge.sh?demo)

Рабочий пример интернет-магазина для моего курса на YouTube по ReactJS + Redux.

[YouTube — Пишем интернет-магазин на ReactJS + Redux](https://www.youtube.com/watch?v=3rq4b6Ozjf8&list=PL0FGkDGJQjJFh-pwkKsksyC4YNJNvzQO8)

**Stack:**

* ReactJS
* Redux
* Redux Thunk
* React Logger
* Axios
* Lodash
* Semantic UI (React)
